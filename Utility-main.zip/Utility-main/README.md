# utility
File Searching compatibility from entire system with a restart &amp; shutdown functionality.
